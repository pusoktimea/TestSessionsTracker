'use strict';

var url = require('url');


var Default = require('./DefaultService');

module.exports.sessionOPTIONS = function sessionOPTIONS (req, res, next) {
  Default.sessionOPTIONS(req.swagger.params, res, next);
};

module.exports.sessionGET = function sessionGET (req, res, next) {
  Default.sessionGET(req.swagger.params, res, next);
};

module.exports.sessionPOST = function sessionPOST (req, res, next) {
  Default.sessionPOST(req.swagger.params, res, next);
};
