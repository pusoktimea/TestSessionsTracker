'use strict';

// exports.sessionOPTIONS = function(args, res, next) {
//   /**
//    * parameters expected in the args:
//   **/
//   // no response value expected for this operation
  
//   res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  
//   res.end();
// }

exports.sessionOPTIONS = function(args, res, next) {
  res.setHeader('Access-Control-Allow-Methods', 'POST, GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'content-type');

  res.end();
};

exports.sessionGET = function(args, res, next) {
  /**
   * parameters expected in the args:
  **/
  
  
  var examples = {};
  examples['application/json'] = {
  "area" : "aeiou",
  "environment" : "aeiou",
  "charter" : "aeiou",
  "tester" : "aeiou",
  "id" : "aeiou"
};
  
  if(Object.keys(examples).length > 0) {
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(examples[Object.keys(examples)[0]] || {}, null, 2));
  }
  else {
    res.end();
  }
  
  
}

exports.sessionPOST = function(args, res, next) {
  /**
   * parameters expected in the args:
  * body (NewSession)
  **/

  console.log(args);
  
  
  res.end();
}

