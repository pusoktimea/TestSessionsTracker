var SessionModel = require("../models/sessions.model");

// var items =  [];
// var item1={
// 	type: 'Setup', description: ''
// 	}
// var item2={
// 	type: 'Test', description: ''
// }

// var session= new Session(
// 	area: 'Exemple area',
// 	environment: 'ex',
// 	charter: 'ex',
// 	tester: 'tester1',
// 	items: items]);

//create function we use to save data to mongodb, sign value to each from request body
exports.create = function (req, res) {
	var data = {
		area: req.body.area,
		environment: req.body.environment,
		charter: req.body.charter,
		tester: req.body.tester,
		items: []
	};

	var session = new SessionModel(data);

	//save the document to mongodb
	session.save();

	res.status(204).end();
};

exports.getSessionNotes = function(req, res){//sa fac o alta functie care apeleaza tot aceasta functie ca parametru 
	console.log("get sessions");

	getLastSession(function(err, session) {// sa trimit la apasarea tastei enter datele de la items - session.items
		if(!err) {
			res.json(session);
		} else {
			res.status(404).end();
		}
	});
}


function getLastSession(callback) {

	var now = new Date();

	SessionModel.find({'endDate': { $gt:now } }).sort({startDate:1}).exec().then(function(sessions) {//query prin care selectez ultima sesiune adaugata
		if(sessions && sessions.length > 0) {
			callback(null, sessions[0])
		} else {
			callback("Session not found", null);
		}
	});
}