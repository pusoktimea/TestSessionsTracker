var mongoose = require("mongoose");
var Schema = mongoose.Schema;

//create the schema
var ItemsSchema = new Schema({
	type: String,
	description: String,
	time: { type:Date, default: Date.now}
});

var SessionSchema = new Schema({
	area:String,
	environment:String,
	charter:String,
	tester:String,
	startDate: { type: Date, default: Date.now },
	endDate: { type: Date, default: Date('3000-01-01')},
	items: [ItemsSchema]
});

//create the model
module.exports = mongoose.model('SessionModel',SessionSchema);

//create a session document and populate it
// var items =  [];
// var item1={
// 	type: 'Setup', description: ''
// 	}
// var item2={
// 	type: 'Test', description: ''
// }

// var session= new Session(
// 	area: 'Exemple area',
// 	environment: 'ex',
// 	charter: 'ex',
// 	tester: 'tester1',
// 	items:items]);

// 	)