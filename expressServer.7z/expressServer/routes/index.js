var express = require('express');
var router = express.Router();
var sessionsctrl= require('../controllers/sessions.controller.js')


module.exports = {

	init: function(app) {
		//Get new session page
		app.get('/newsession', function(req, res){
			return sessionsctrl.getSessionNotes(req, res);
		});

		// POST, to create a new session
		app.post('/newsession', function(req, res){
			return sessionsctrl.create(req, res);
		});
	}		
};
